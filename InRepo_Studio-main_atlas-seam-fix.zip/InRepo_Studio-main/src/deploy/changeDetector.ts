/**
 * SCHEMA INVENTORY (lists-of-truth)
 * Owner: this file
 * Purpose: Detect local changes and resolve deploy conflicts.
 *
 * Defines:
 * - FileChangeSchema — deploy file change shape (type: schema)
 * - ConflictSchema — conflict metadata (type: schema)
 *
 * Canonical key set:
 * - Keys come from: this file (authoritative source)
 * - Export/Import policy: not exported
 *
 * Apply/Rebuild semantics:
 * - Apply mode: live (computed during deploy)
 *
 * Verification (minimum):
 * - [ ] Detects modified project.json and scene files
 * - [ ] Ignores unchanged files (content hash match)
 */

import type { HotProject } from '@/storage';
import type { Scene } from '@/types';
import type { SpriteAtlas, SpriteAtlasSlice } from '@/types/project';
import type { ShaStore } from './shaManager';
import type { AssetRegistryState } from '@/editor/assets';
import type { AssetGroupType } from '@/editor/assets/assetGroup';
import { ASSET_GROUP_PATHS } from '@/editor/assets/assetGroup';
import { PROJECT_JSON_PATH, SCENE_INDEX_JSON_PATH, SCENES_DIR } from '@/shared/paths';
import { hashContent } from './utils';
import { parseDataUrl, slugifyFileName, buildUniqueFileName, MIME_EXTENSION_MAP } from './assetUpload';

export type FileChangeStatus = 'added' | 'modified' | 'deleted';

export interface FileChange {
  path: string;
  status: FileChangeStatus;
  content: string | null;
  contentHash: string | null;
  localSha: string | null;
  encoding?: 'utf-8' | 'base64';
}

export interface ChangeDetectorConfig {
  getProject: () => Promise<HotProject | null>;
  getScenes: () => Promise<Scene[]>;
  getShaStore: () => Promise<ShaStore>;
  getAssetRegistryState?: () => AssetRegistryState | null;
}

export interface ChangeDetector {
  detectChanges(): Promise<FileChange[]>;
}

export interface ConflictInfo {
  path: string;
  localSha: string | null;
  remoteSha: string | null;
  hasConflict: boolean;
}

export interface ConflictResult {
  safe: FileChange[];
  conflicts: (FileChange & ConflictInfo)[];
}

function detectContentChange(
  previousHash: string | null,
  currentHash: string
): boolean {
  if (!previousHash) {
    return true;
  }
  return previousHash !== currentHash;
}

/**
 * Build the deploy path for a local asset within a group.
 * Mirrors the path structure used by assetUpload.ts so that SHA tracking
 * remains consistent across both upload mechanisms.
 */
function buildAssetDeployPath(
  groupType: AssetGroupType,
  groupSlug: string,
  fileName: string
): string {
  const basePath = ASSET_GROUP_PATHS[groupType];
  return `${basePath}/${groupSlug}/${fileName}`;
}

function findParentInGroups(
  groups: AssetRegistryState['groups'],
  parentId: string
): { asset: AssetRegistryState['groups'][number]['assets'][number]; groupIndex: number } | null {
  for (let gi = 0; gi < groups.length; gi++) {
    const asset = groups[gi].assets.find((a) => a.id === parentId);
    if (asset) return { asset, groupIndex: gi };
  }
  return null;
}

export function createChangeDetector(config: ChangeDetectorConfig): ChangeDetector {
  const { getProject, getScenes, getShaStore, getAssetRegistryState } = config;

  return {
    async detectChanges() {
      const shaStore = await getShaStore();
      const changes: FileChange[] = [];
      const currentPaths = new Set<string>();

      // --- Phase 1: Detect image asset changes ---
      // Process assets before project.json so we can inject spriteAtlases
      // metadata into the deployed project content.
      const registryState = getAssetRegistryState?.() ?? null;
      const spriteAtlases: SpriteAtlas[] = [];
      const parentDeployPaths = new Map<string, string>();

      if (registryState) {
        // Upload only parent/standalone assets (skip slice assets that
        // reference a parent via sourceAssetId — they share the same
        // full-sheet dataUrl and would be uploaded redundantly).
        for (const group of registryState.groups) {
          const usedNames = new Set<string>();
          for (const asset of group.assets) {
            if (asset.source !== 'local') continue;
            if (asset.sourceAssetId) continue;

            const parsed = parseDataUrl(asset.dataUrl);
            if (!parsed) continue;

            const extension = MIME_EXTENSION_MAP[parsed.mimeType];
            if (!extension) continue;

            const fileName = buildUniqueFileName(
              slugifyFileName(asset.name),
              extension,
              usedNames
            );
            const assetPath = buildAssetDeployPath(group.type, group.slug, fileName);
            const contentHash = await hashContent(parsed.base64);
            const entry = shaStore.get(assetPath);

            currentPaths.add(assetPath);
            parentDeployPaths.set(asset.id, assetPath);

            if (detectContentChange(entry?.contentHash ?? null, contentHash)) {
              changes.push({
                path: assetPath,
                status: entry ? 'modified' : 'added',
                content: parsed.base64,
                contentHash,
                localSha: entry?.sha ?? null,
                encoding: 'base64',
              });
            }
          }
        }

        // Build spriteAtlases from ALL slice assets (local + repo) that
        // reference a parent. This preserves per-slice category overrides
        // so that after deploy + reload, slices rehydrate into the correct
        // Asset Library category.
        const atlasMap = new Map<string, {
          name: string;
          parentPath: string;
          parentGroupKey: string;
          slices: Array<SpriteAtlasSlice & { _groupKey: string }>;
          firstSliceSize: { width: number; height: number };
        }>();

        // Build a lookup: assetId → group for fast parent/slice group resolution
        const assetGroupLookup = new Map<string, { type: AssetGroupType; slug: string }>();
        for (const group of registryState.groups) {
          for (const asset of group.assets) {
            assetGroupLookup.set(asset.id, { type: group.type, slug: group.slug });
          }
        }

        for (const group of registryState.groups) {
          for (const asset of group.assets) {
            if (!asset.sourceAssetId || !asset.rect) continue;

            // Resolve parent path:
            // - local parent: use computed deploy path, strip "game/" prefix
            // - repo parent: dataUrl is already repo-relative
            let parentPath: string | null = null;
            if (parentDeployPaths.has(asset.sourceAssetId)) {
              parentPath = parentDeployPaths.get(asset.sourceAssetId)!.replace(/^game\//, '');
            } else {
              // Find the parent asset to get its dataUrl (repo asset path)
              const parentInfo = findParentInGroups(registryState.groups, asset.sourceAssetId);
              if (parentInfo) {
                parentPath = parentInfo.asset.dataUrl;
              }
            }
            if (!parentPath) continue;

            if (!atlasMap.has(asset.sourceAssetId)) {
              const parentInfo = findParentInGroups(registryState.groups, asset.sourceAssetId);
              const parentGroup = assetGroupLookup.get(asset.sourceAssetId);
              const parentGroupKey = parentGroup
                ? `${parentGroup.type}:${parentGroup.slug}`
                : `${group.type}:${group.slug}`;
              atlasMap.set(asset.sourceAssetId, {
                name: parentInfo?.asset.name ?? asset.sourceAssetId,
                parentPath,
                parentGroupKey,
                slices: [],
                firstSliceSize: { width: asset.rect.w, height: asset.rect.h },
              });
            }

            const sliceGroupKey = `${group.type}:${group.slug}`;
            atlasMap.get(asset.sourceAssetId)!.slices.push({
              name: asset.name,
              rect: { x: asset.rect.x, y: asset.rect.y, w: asset.rect.w, h: asset.rect.h },
              _groupKey: sliceGroupKey,
            });
          }
        }

        for (const [, atlas] of atlasMap) {
          // Sort slices for stable output across runs
          atlas.slices.sort((a, b) =>
            a.rect.y - b.rect.y
            || a.rect.x - b.rect.x
            || a.rect.h - b.rect.h
            || a.rect.w - b.rect.w
            || a.name.localeCompare(b.name)
          );

          const defaultGroup = atlas.parentGroupKey;
          const outputSlices: SpriteAtlasSlice[] = atlas.slices.map((s) => {
            const slice: SpriteAtlasSlice = {
              name: s.name,
              rect: s.rect,
            };
            // Only set per-slice group override when it differs from atlas default
            if (s._groupKey !== defaultGroup) {
              slice.group = s._groupKey;
            }
            return slice;
          });

          const spriteAtlas: SpriteAtlas = {
            name: atlas.name,
            path: atlas.parentPath,
            sliceSize: atlas.firstSliceSize,
            slices: outputSlices,
            defaultGroup,
          };

          spriteAtlases.push(spriteAtlas);
        }

        // Sort atlases by path for stable JSON output
        spriteAtlases.sort((a, b) => a.path.localeCompare(b.path));
      }

      // --- Phase 2: Detect project.json changes ---
      // Merge computed spriteAtlases into the deployed project content so
      // the runtime can reconstruct sprite frames from the parent sheet.
      const hotProject = await getProject();
      if (hotProject) {
        const projectData = spriteAtlases.length > 0
          ? { ...hotProject.project, spriteAtlases }
          : hotProject.project;
        const projectPath = PROJECT_JSON_PATH;
        const projectContent = JSON.stringify(projectData, null, 2);
        const contentHash = await hashContent(projectContent);
        const entry = shaStore.get(projectPath);

        currentPaths.add(projectPath);

        if (detectContentChange(entry?.contentHash ?? null, contentHash)) {
          changes.push({
            path: projectPath,
            status: entry ? 'modified' : 'added',
            content: projectContent,
            contentHash,
            localSha: entry?.sha ?? null,
          });
        }
      }

      // --- Phase 3: Detect scene changes ---
      const scenes = await getScenes();
      for (const scene of scenes) {
        const scenePath = `${SCENES_DIR}/${scene.id}.json`;
        const sceneContent = JSON.stringify(scene, null, 2);
        const contentHash = await hashContent(sceneContent);
        const entry = shaStore.get(scenePath);

        currentPaths.add(scenePath);

        if (detectContentChange(entry?.contentHash ?? null, contentHash)) {
          changes.push({
            path: scenePath,
            status: entry ? 'modified' : 'added',
            content: sceneContent,
            contentHash,
            localSha: entry?.sha ?? null,
          });
        }
      }

      const sceneIndexIds = scenes.map((scene) => scene.id);
      const sceneIndexContent = JSON.stringify(sceneIndexIds, null, 2);
      const sceneIndexHash = await hashContent(sceneIndexContent);
      const indexEntry = shaStore.get(SCENE_INDEX_JSON_PATH);

      currentPaths.add(SCENE_INDEX_JSON_PATH);

      if (detectContentChange(indexEntry?.contentHash ?? null, sceneIndexHash)) {
        changes.push({
          path: SCENE_INDEX_JSON_PATH,
          status: indexEntry ? 'modified' : 'added',
          content: sceneIndexContent,
          contentHash: sceneIndexHash,
          localSha: indexEntry?.sha ?? null,
        });
      }

      // --- Phase 4: Detect deleted files ---
      const storedEntries = shaStore.getAll();
      Object.keys(storedEntries).forEach((path) => {
        if (!currentPaths.has(path)) {
          changes.push({
            path,
            status: 'deleted',
            content: null,
            contentHash: null,
            localSha: storedEntries[path]?.sha ?? null,
          });
        }
      });

      return changes;
    },
  };
}

export function detectConflicts(
  changes: FileChange[],
  remoteShas: Record<string, string | null>
): ConflictResult {
  const safe: FileChange[] = [];
  const conflicts: (FileChange & ConflictInfo)[] = [];

  for (const change of changes) {
    const remoteSha = remoteShas[change.path] ?? null;
    const hasConflict = (() => {
      // Safety rules:
      // - If remote changed since last deploy (SHA differs), require user choice.
      // - Remote deletion is also a change: if we previously deployed a file (localSha)
      //   but it is now missing remotely, treat as a conflict for add/modify.
      if (change.status === 'deleted') {
        // If remote is already missing, deletion is a no-op (safe).
        // If remote exists and SHA differs, someone changed it since last deploy.
        return remoteSha !== null && change.localSha !== remoteSha;
      }

      // added/modified
      if (remoteSha === null) {
        // Remote missing but we have a localSha means it was deleted remotely.
        return change.localSha !== null;
      }

      // Remote exists.
      return change.localSha !== remoteSha;
    })();

    if (hasConflict) {
      conflicts.push({
        ...change,
        remoteSha,
        hasConflict: true,
      });
    } else {
      safe.push(change);
    }
  }

  return { safe, conflicts };
}

import { LEFT_BERRY_TABS, type LeftBerryTab, type LeftBerryTabId } from './leftBerryTabs';
import { createSpriteSlicerTab } from './spriteSlicerTab';
import { createAssetLibraryTab, type AssetLibraryTabController } from './assetLibraryTab';
import type { AssetEntryInput, AssetRegistry } from '@/editor/assets';
import type { EditorState } from '@/storage/hot';
import type { EntityManager } from '@/editor/entities/entityManager';
import type { HistoryManager } from '@/editor/history';
import type { Scene } from '@/types';
import { createAnimationTab, type AnimationTabController } from './animationTab';
import type { PresetRegistry } from '@/runtime/presets/presetRegistry';
import type { PresetConfigStore } from '@/editor/presets/presetConfigStore';
import { createPresetsTab, type PresetsTabController } from '@/editor/presets/presetsTab';

export interface LeftBerryConfig {
  initialOpen?: boolean;
  initialTab?: LeftBerryTabId;
  tabs?: LeftBerryTab[];
  assetRegistry?: AssetRegistry;
  assetLibraryEnabled?: boolean;
  assetUploadEnabled?: boolean;
  getEditorState?: () => EditorState | null;
  getCurrentScene?: () => Scene | null;
  entityManager?: EntityManager;
  history?: HistoryManager;
  presetRegistry?: PresetRegistry;
  presetConfigStore?: PresetConfigStore;
}

export interface LeftBerryController {
  open(tab?: LeftBerryTabId): void;
  openAnimation(animationId: string): void;
  close(): void;
  isOpen(): boolean;
  getActiveTab(): LeftBerryTabId | null;
  setActiveTab(tab: LeftBerryTabId, options?: { silent?: boolean }): void;
  getTabContentContainer(tab: LeftBerryTabId): HTMLElement | null;
  onTabChange(callback: (tab: LeftBerryTabId) => void): void;
  onOpenChange(callback: (open: boolean) => void): void;
  refreshTab(tab: LeftBerryTabId): void;
  setInsertBlockFn(fn: ((blockType: string) => void) | null): void;
  setOpenInBlocklyFn(fn: ((blockType: string) => void | Promise<void>) | null): void;
  destroy(): void;
}

const STYLES = `
  .left-berry-shell {
    position: fixed;
    inset: 0;
    pointer-events: none;
    z-index: 20;
  }

  .left-berry__overlay {
    position: absolute;
    inset: 0;
    background: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(4px);
    -webkit-backdrop-filter: blur(4px);
    opacity: 0;
    transition: opacity 0.25s ease-out;
    pointer-events: none;
  }

  .left-berry-shell--open .left-berry__overlay {
    opacity: 1;
    pointer-events: auto;
  }

  .left-berry {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: min(320px, 85vw);
    background: #0d1220;
    border-right: 1px solid rgba(255, 255, 255, 0.08);
    box-shadow: 4px 0 24px rgba(0, 0, 0, 0.5);
    transform: translateX(-100%);
    transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  @media (max-width: 520px) {
    .left-berry {
      width: 100vw;
    }
  }

  .left-berry-shell--open .left-berry {
    transform: translateX(0);
    pointer-events: auto;
  }

  .left-berry__header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 16px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.06);
    flex-shrink: 0;
  }

  .left-berry__title {
    font-size: 16px;
    font-weight: 600;
    color: #fff;
  }

  .left-berry__close {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    border: none;
    background: rgba(255, 255, 255, 0.06);
    color: rgba(255, 255, 255, 0.6);
    font-size: 18px;
    font-weight: 300;
    cursor: pointer;
    -webkit-tap-highlight-color: transparent;
    transition: background 0.15s, color 0.15s;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .left-berry__close:active {
    background: rgba(255, 255, 255, 0.1);
    color: #fff;
  }

  .left-berry__tabs {
    display: flex;
    gap: 6px;
    padding: 12px 16px;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    border-bottom: 1px solid rgba(255, 255, 255, 0.06);
    scrollbar-width: none;
    flex-shrink: 0;
  }

  .left-berry__tabs::-webkit-scrollbar {
    display: none;
  }

  .left-berry__tab {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    height: 40px;
    padding: 0 16px;
    border-radius: 8px;
    border: none;
    background: transparent;
    color: rgba(255, 255, 255, 0.5);
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    white-space: nowrap;
    -webkit-tap-highlight-color: transparent;
    transition: all 0.15s ease;
  }

  .left-berry__tab:active {
    background: rgba(255, 255, 255, 0.05);
  }

  .left-berry__tab--active {
    background: rgba(255, 255, 255, 0.08);
    color: #fff;
  }

  .left-berry__tab-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 20px;
    font-size: 12px;
    opacity: 0.7;
  }

  .left-berry__tab--active .left-berry__tab-icon {
    opacity: 1;
  }

  .left-berry__content {
    flex: 1;
    display: flex;
    flex-direction: column;
    min-height: 0;
    overflow: hidden;
  }

  .left-berry__tab-content {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    padding: 16px;
    display: none;
    -webkit-overflow-scrolling: touch;
  }

  .left-berry__tab-content::-webkit-scrollbar {
    width: 4px;
  }

  .left-berry__tab-content::-webkit-scrollbar-track {
    background: transparent;
  }

  .left-berry__tab-content::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.15);
    border-radius: 2px;
  }

  .left-berry__tab-content--active {
    display: flex;
    flex-direction: column;
  }

  .left-berry__placeholder {
    color: rgba(255, 255, 255, 0.4);
    font-size: 13px;
    line-height: 1.5;
    background: rgba(255, 255, 255, 0.03);
    border: 1px dashed rgba(255, 255, 255, 0.1);
    border-radius: 8px;
    padding: 16px;
  }

  /* Slim edge handle */
  .left-berry__handle {
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    width: 28px;
    height: 64px;
    padding: 0;
    border: none;
    background: transparent;
    cursor: pointer;
    pointer-events: auto;
    -webkit-tap-highlight-color: transparent;
    display: flex;
    align-items: center;
    justify-content: flex-start;
  }

  .left-berry__handle-tab {
    width: 20px;
    height: 56px;
    background: rgba(30, 40, 60, 0.9);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-left: none;
    border-radius: 0 10px 10px 0;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
    box-shadow: 2px 0 8px rgba(0, 0, 0, 0.3);
  }

  .left-berry__handle:active .left-berry__handle-tab {
    background: rgba(40, 55, 80, 0.95);
    width: 24px;
  }

  .left-berry__handle-icon {
    color: rgba(255, 255, 255, 0.5);
    font-size: 10px;
    transition: color 0.2s;
  }

  .left-berry__handle:active .left-berry__handle-icon {
    color: rgba(255, 255, 255, 0.8);
  }

  .left-berry-shell--open .left-berry__handle {
    opacity: 0;
    pointer-events: none;
  }
`;

function ensureStyles(): void {
  if (document.getElementById('left-berry-styles')) return;
  const styleEl = document.createElement('style');
  styleEl.id = 'left-berry-styles';
  styleEl.textContent = STYLES;
  document.head.appendChild(styleEl);
}

export function createLeftBerry(container: HTMLElement, config: LeftBerryConfig = {}): LeftBerryController {
  ensureStyles();

  const tabs = config.tabs ?? LEFT_BERRY_TABS;
  const activeTabId = config.initialTab ?? tabs[0]?.id ?? 'sprites';
  let isOpen = config.initialOpen ?? false;
  let currentTab: LeftBerryTabId | null = null;
  const tabChangeCallbacks: Array<(tab: LeftBerryTabId) => void> = [];
  const openChangeCallbacks: Array<(open: boolean) => void> = [];
  const assetRegistry = config.assetRegistry;
  const assetLibraryEnabled = config.assetLibraryEnabled ?? true;
  const assetUploadEnabled = config.assetUploadEnabled ?? false;
  const getEditorState = config.getEditorState;
  const entityManager = config.entityManager;
  const history = config.history;
  let assetLibraryController: AssetLibraryTabController | null = null;
  let animationTabController: AnimationTabController | null = null;
  let presetsTabController: PresetsTabController | null = null;

  const shell = document.createElement('div');
  shell.className = 'left-berry-shell';

  const overlay = document.createElement('div');
  overlay.className = 'left-berry__overlay';

  const panel = document.createElement('div');
  panel.className = 'left-berry';

  const header = document.createElement('div');
  header.className = 'left-berry__header';

  const title = document.createElement('div');
  title.className = 'left-berry__title';
  title.textContent = 'Assets';

  const closeButton = document.createElement('button');
  closeButton.type = 'button';
  closeButton.className = 'left-berry__close';
  closeButton.textContent = '×';

  header.appendChild(title);
  header.appendChild(closeButton);

  const tabBar = document.createElement('div');
  tabBar.className = 'left-berry__tabs';

  const content = document.createElement('div');
  content.className = 'left-berry__content';

  const tabContentMap = new Map<LeftBerryTabId, HTMLElement>();

  tabs.forEach((tab) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'left-berry__tab';
    button.dataset.tab = tab.id;
    button.innerHTML = `<span class="left-berry__tab-icon">${tab.icon}</span>${tab.label}`;
    button.addEventListener('click', () => setActiveTab(tab.id));
    tabBar.appendChild(button);

    const tabContent = document.createElement('div');
    tabContent.className = 'left-berry__tab-content';
    tabContent.dataset.tab = tab.id;
    content.appendChild(tabContent);
    tabContentMap.set(tab.id, tabContent);
  });

  panel.appendChild(header);
  panel.appendChild(tabBar);
  panel.appendChild(content);

  // Slim edge-hugging handle
  const handle = document.createElement('button');
  handle.type = 'button';
  handle.className = 'left-berry__handle';
  handle.setAttribute('aria-label', 'Open asset panel');

  const handleTab = document.createElement('div');
  handleTab.className = 'left-berry__handle-tab';

  const handleIcon = document.createElement('div');
  handleIcon.className = 'left-berry__handle-icon';
  handleIcon.textContent = '›';

  handleTab.appendChild(handleIcon);
  handle.appendChild(handleTab);

  shell.appendChild(overlay);
  shell.appendChild(panel);
  shell.appendChild(handle);

  container.appendChild(shell);

  const spritesContainer = tabContentMap.get('sprites');
  if (spritesContainer) {
    createSpriteSlicerTab({
      container: spritesContainer,
      onSlicesConfirmed: (payload) => {
        if (!assetRegistry) return;
        const { slices, groupName, groupType, imageName, sliceSize } = payload;
        const baseName = groupName || imageName || 'Asset Group';
        const assetsToAdd: AssetEntryInput[] = slices.map((slice, index) => ({
          name: `${baseName} ${index + 1}`,
          type: groupType === 'entities' ? 'entity' : groupType === 'props' ? 'sprite' : 'tile',
          dataUrl: slice.dataUrl,
          width: sliceSize.width,
          height: sliceSize.height,
          source: 'local',
        }));
        assetRegistry.addAssets({
          groupType,
          groupName: baseName,
          assets: assetsToAdd,
        });
        setActiveTab('assets');
      },
      onAtlasConfirmed: (payload) => {
        if (!assetRegistry) return;
        const { imageDataUrl, imageWidth, imageHeight, slices, groupName, groupType, imageName } = payload;
        const baseName = groupName || imageName || 'Asset Group';
        const assetType = groupType === 'entities' ? 'entity' as const : groupType === 'props' ? 'sprite' as const : 'tile' as const;

        // Import the spritesheet as a single source asset
        const sourceAssets = assetRegistry.addAssets({
          groupType,
          groupName: baseName,
          assets: [{
            name: `${baseName} (sheet)`,
            type: assetType,
            dataUrl: imageDataUrl,
            width: imageWidth,
            height: imageHeight,
            source: 'local',
          }],
        });
        const sourceAsset = sourceAssets[0];
        if (!sourceAsset) return;

        // Create slice entries referencing the source sheet
        const sliceAssets: AssetEntryInput[] = slices.map((slice) => ({
          name: slice.name,
          type: assetType,
          dataUrl: imageDataUrl,
          width: slice.rect.w,
          height: slice.rect.h,
          source: 'local' as const,
          sourceAssetId: sourceAsset.id,
          rect: { ...slice.rect },
        }));
        assetRegistry.addAssets({
          groupType,
          groupName: baseName,
          assets: sliceAssets,
        });
        setActiveTab('assets');
      },
    });
  }

  const animationContainer = tabContentMap.get('animation');
  if (animationContainer) {
    if (assetRegistry) {
      animationTabController = createAnimationTab({
        container: animationContainer,
        assetRegistry,
        getEditorState: getEditorState ?? (() => null),
        entityManager,
        history,
        onBackToList: () => setActiveTab('assets'),
      });
    } else {
      animationContainer.appendChild(
        createLeftBerryPlaceholder('Animation tools need an asset registry to run.')
      );
    }
  }

  const assetsContainer = tabContentMap.get('assets');
  if (assetsContainer) {
    if (assetLibraryEnabled && assetRegistry) {
      assetLibraryController = createAssetLibraryTab({
        container: assetsContainer,
        assetRegistry,
        uploadEnabled: assetUploadEnabled,
        getCurrentScene: config.getCurrentScene,
        entityManager,
        onOpenAnimation: (id) => {
          setActiveTab('animation');
          animationTabController?.openAnimation(id);
        },
      });
    } else {
      assetsContainer.appendChild(createLeftBerryPlaceholder('Asset library is disabled for this session.'));
    }
  }

  const presetsContainer = tabContentMap.get('presets');
  if (presetsContainer) {
    if (config.presetRegistry && config.presetConfigStore) {
      presetsTabController = createPresetsTab({
        container: presetsContainer,
        registry: config.presetRegistry,
        configStore: config.presetConfigStore,
      });
    } else {
      presetsContainer.appendChild(
        createLeftBerryPlaceholder('Presets require a project to be loaded.')
      );
    }
  }

  function setActiveTab(tab: LeftBerryTabId, options?: { silent?: boolean }): void {
    if (currentTab !== null && currentTab === tab) return;
    currentTab = tab;

    for (const button of tabBar.querySelectorAll<HTMLButtonElement>('.left-berry__tab')) {
      const isActive = button.dataset.tab === tab;
      button.classList.toggle('left-berry__tab--active', isActive);
    }

    for (const tabContent of tabContentMap.values()) {
      const isActive = tabContent.dataset.tab === tab;
      tabContent.classList.toggle('left-berry__tab-content--active', isActive);
    }

    if (tab === 'animation') {
      animationTabController?.refresh();
    }

    if (!options?.silent) {
      tabChangeCallbacks.forEach((cb) => cb(tab));
    }
  }

  function updateOpenState(nextOpen: boolean): void {
    if (isOpen === nextOpen) return;
    isOpen = nextOpen;
    shell.classList.toggle('left-berry-shell--open', isOpen);
    openChangeCallbacks.forEach((cb) => cb(isOpen));
  }

  function handleClose(): void {
    updateOpenState(false);
  }

  let touchStartX = 0;
  let touchStartY = 0;
  let touchActive = false;
  let swipeCancelled = false;

  function onTouchStart(evt: TouchEvent): void {
    if (!isOpen) return;
    if (evt.touches.length !== 1) return;
    const touch = evt.touches[0];
    const target = evt.target as HTMLElement | null;

    // Ignore swipes that start on the tab strip (those are tab navigation)
    if (target?.closest('.left-berry__tabs')) {
      touchActive = false;
      return;
    }

    // Ignore swipes that start in scrollable content areas
    if (target?.closest('.left-berry__tab-content')) {
      touchActive = false;
      return;
    }

    touchStartX = touch.clientX;
    touchStartY = touch.clientY;
    touchActive = true;
    swipeCancelled = false;
  }

  function onTouchMove(evt: TouchEvent): void {
    if (!touchActive || swipeCancelled) return;
    const touch = evt.touches[0];
    const dx = Math.abs(touch.clientX - touchStartX);
    const dy = Math.abs(touch.clientY - touchStartY);

    // If vertical movement dominates, cancel swipe-to-close (user is scrolling)
    if (dy > 15 && dy > dx) {
      swipeCancelled = true;
    }
  }

  function onTouchEnd(evt: TouchEvent): void {
    if (!touchActive || swipeCancelled) {
      touchActive = false;
      swipeCancelled = false;
      return;
    }
    touchActive = false;

    const touch = evt.changedTouches[0];
    const dx = touch.clientX - touchStartX;
    const dy = touch.clientY - touchStartY;

    if (Math.abs(dx) > 80 && Math.abs(dy) < 40 && dx < 0) {
      handleClose();
    }
  }

  overlay.addEventListener('click', handleClose);
  closeButton.addEventListener('click', handleClose);
  handle.addEventListener('click', () => updateOpenState(true));
  panel.addEventListener('touchstart', onTouchStart);
  panel.addEventListener('touchmove', onTouchMove, { passive: true });
  panel.addEventListener('touchend', onTouchEnd);

  shell.classList.toggle('left-berry-shell--open', isOpen);
  setActiveTab(activeTabId, { silent: true });

  return {
    open: (tab) => {
      updateOpenState(true);
      if (tab) setActiveTab(tab);
    },
    openAnimation: (animationId) => {
      updateOpenState(true);
      setActiveTab('animation');
      animationTabController?.openAnimation(animationId);
    },
    close: () => updateOpenState(false),
    isOpen: () => isOpen,
    getActiveTab: () => currentTab,
    setActiveTab,
    getTabContentContainer: (tab) => tabContentMap.get(tab) ?? null,
    onTabChange: (callback) => tabChangeCallbacks.push(callback),
    onOpenChange: (callback) => openChangeCallbacks.push(callback),
    refreshTab: (tab) => {
      if (tab === 'animation') {
        animationTabController?.refresh();
      }
      if (tab === 'assets') {
        assetLibraryController?.refresh();
      }
      if (tab === 'presets') {
        presetsTabController?.refresh();
      }
    },
    setInsertBlockFn: (fn) => {
      presetsTabController?.setInsertBlockFn(fn);
    },

    setOpenInBlocklyFn: (fn) => {
      presetsTabController?.setOpenInBlocklyFn(fn);
    },
    destroy: () => {
      panel.removeEventListener('touchstart', onTouchStart);
      panel.removeEventListener('touchmove', onTouchMove);
      panel.removeEventListener('touchend', onTouchEnd);
      assetLibraryController?.destroy();
      animationTabController?.destroy();
      presetsTabController?.destroy();
      container.removeChild(shell);
    },
  };
}

export function createLeftBerryPlaceholder(text: string): HTMLElement {
  const placeholder = document.createElement('div');
  placeholder.className = 'left-berry__placeholder';
  placeholder.textContent = text;
  return placeholder;
}

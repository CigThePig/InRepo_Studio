import type { EditorState } from '@/storage/hot';
import type { AssetRegistry } from '@/editor/assets';
import type { EntityInstance, Project } from '@/types';
import { validatePropertyValue, type PropertyDefinition } from '@/types/entity';
import type { EntityManager } from '@/editor/entities/entityManager';
import { generateOperationId, type HistoryManager, type Operation } from '@/editor/history';
import { createAssetPalette, type AssetPaletteController } from './assetPalette';

const STYLES = `
  .entities-tab {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .entities-tab__section {
    background: rgba(20, 30, 60, 0.85);
    border: 1px solid #253461;
    border-radius: 14px;
    padding: 12px;
    color: #e6ecff;
  }

  .entities-tab__section-title {
    font-size: 13px;
    font-weight: 700;
    color: #dbe4ff;
    margin-bottom: 8px;
  }

  .entities-tab__palette {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .entities-tab__palette-row {
    display: flex;
    gap: 8px;
    align-items: center;
  }

  .entities-tab__palette-button {
    min-height: 44px;
    padding: 8px 12px;
    border-radius: 12px;
    border: 2px solid transparent;
    background: #1b2a52;
    color: #dbe4ff;
    font-size: 13px;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
    -webkit-tap-highlight-color: transparent;
    flex: 1;
  }

  .entities-tab__palette-button:active {
    background: #26386a;
  }

  .entities-tab__palette-button--active {
    border-color: #4a9eff;
    background: #2a3e74;
    color: #ffffff;
  }

  .entities-tab__palette-tag {
    font-size: 11px;
    color: #9fb2e3;
  }

  .entities-tab__place-button {
    min-width: 64px;
    height: 44px;
    padding: 0 12px;
    border-radius: 12px;
    border: none;
    background: rgba(74, 158, 255, 0.18);
    color: #eaf2ff;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    -webkit-tap-highlight-color: transparent;
  }

  .entities-tab__place-button:active {
    background: rgba(74, 158, 255, 0.28);
  }

  .entities-tab__selection-title {
    font-size: 14px;
    font-weight: 700;
  }

  .entities-tab__selection-subtitle {
    font-size: 12px;
    color: #9aa7d6;
    margin-top: 4px;
  }

  .entities-tab__empty {
    font-size: 12px;
    color: #8c94c9;
    padding: 6px 0;
  }

  .entities-tab__property-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .entities-tab__property-row {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding-bottom: 10px;
    border-bottom: 1px solid rgba(62, 84, 148, 0.25);
  }

  .entities-tab__property-row:last-child {
    border-bottom: none;
  }

  .entities-tab__label {
    font-size: 12px;
    font-weight: 600;
    color: #dbe4ff;
  }

  .entities-tab__input,
  .entities-tab__toggle {
    min-height: 44px;
    border-radius: 10px;
    border: 1px solid rgba(83, 101, 164, 0.6);
    background: rgba(22, 30, 60, 0.85);
    color: #f2f5ff;
    padding: 8px 12px;
    font-size: 13px;
  }

  .entities-tab__toggle {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    cursor: pointer;
    -webkit-tap-highlight-color: transparent;
  }

  .entities-tab__toggle--active {
    border-color: #4a9eff;
    background: rgba(74, 158, 255, 0.2);
    color: #ffffff;
  }

  .entities-tab__hint {
    font-size: 11px;
    color: #8f98c8;
  }

  .entities-tab__error {
    font-size: 11px;
    color: #ff9fb3;
  }

  .entities-tab__property-row--error .entities-tab__input,
  .entities-tab__property-row--error .entities-tab__toggle {
    border-color: rgba(255, 124, 152, 0.8);
  }

  .entities-tab__toggle-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }

  .entities-tab__action-row {
    display: flex;
    gap: 8px;
    margin-top: 10px;
  }

  .entities-tab__action-button {
    min-height: 44px;
    border-radius: 10px;
    border: 1px solid rgba(83, 101, 164, 0.6);
    background: rgba(33, 46, 89, 0.85);
    color: #f2f5ff;
    font-size: 13px;
    font-weight: 700;
    padding: 10px 12px;
    cursor: pointer;
    -webkit-tap-highlight-color: transparent;
    flex: 1;
  }

  .entities-tab__action-button:active {
    background: rgba(52, 70, 128, 0.9);
  }

  .entities-tab__action-button:disabled {
    opacity: 0.45;
    cursor: not-allowed;
  }
`;

export interface EntitiesTabConfig {
  container: HTMLElement;
  getProject: () => Project | null;
  getEditorState: () => EditorState | null;
  entityManager: EntityManager;
  history: HistoryManager;
  assetRegistry?: AssetRegistry;
  onEntityTypeSelect?: (typeName: string | null) => void;
  onEntityTypePlace?: (typeName: string) => void;
  onEntitySnapChange?: (enabled: boolean) => void;
  onEditAnimation?: (animationId: string) => void;
}

export interface EntitiesTabController {
  setSelection(selectedIds: string[]): void;
  refresh(): void;
  destroy(): void;
}

function buildConstraintHint(definition: PropertyDefinition): string | null {
  const constraints = definition.constraints;
  if (!constraints) return null;
  const parts: string[] = [];
  if (definition.type === 'number') {
    if (constraints.min !== undefined) parts.push(`Min ${constraints.min}`);
    if (constraints.max !== undefined) parts.push(`Max ${constraints.max}`);
  }

  if (definition.type === 'string' || definition.type === 'assetRef') {
    if (constraints.minLength !== undefined) parts.push(`Min length ${constraints.minLength}`);
    if (constraints.maxLength !== undefined) parts.push(`Max length ${constraints.maxLength}`);
    if (constraints.pattern) parts.push('Pattern required');
  }

  if (constraints.assetType) {
    parts.push(`Asset type: ${constraints.assetType}`);
  }

  return parts.length > 0 ? parts.join(' · ') : null;
}

function collectAssetOptions(project: Project | null): string[] {
  if (!project) return [];
  const options: string[] = [];

  for (const category of project.tileCategories ?? []) {
    for (const file of category.files ?? []) {
      options.push(`${category.path}/${file}`);
    }
  }

  for (const type of project.entityTypes ?? []) {
    if (type.sprite) {
      options.push(type.sprite);
    }
  }

  return Array.from(new Set(options));
}

function getEntityTypeLabel(entityType: Project['entityTypes'][number] | undefined): string {
  if (!entityType) return 'Unknown';
  return entityType.displayName ?? entityType.name;
}

export function createEntitiesTab(config: EntitiesTabConfig): EntitiesTabController {
  const {
    container,
    getProject,
    getEditorState,
    entityManager,
    history,
    assetRegistry,
    onEntityTypeSelect,
  } = config;

  const styleEl = document.createElement('style');
  styleEl.textContent = STYLES;
  document.head.appendChild(styleEl);

  const root = document.createElement('div');
  root.className = 'entities-tab';

  const paletteSection = document.createElement('section');
  paletteSection.className = 'entities-tab__section';

  const paletteTitle = document.createElement('div');
  paletteTitle.className = 'entities-tab__section-title';
  paletteTitle.textContent = 'Entity Palette';

  const paletteList = document.createElement('div');
  paletteList.className = 'entities-tab__palette';

  paletteSection.appendChild(paletteTitle);
  paletteSection.appendChild(paletteList);

  const placementSection = document.createElement('section');
  placementSection.className = 'entities-tab__section';

  const placementTitle = document.createElement('div');
  placementTitle.className = 'entities-tab__section-title';
  placementTitle.textContent = 'Placement';

  const placementRow = document.createElement('div');
  placementRow.className = 'entities-tab__toggle-row';

  const placementLabel = document.createElement('div');
  placementLabel.className = 'entities-tab__label';
  placementLabel.textContent = 'Snap to Grid';

  const snapToggle = document.createElement('button');
  snapToggle.type = 'button';
  snapToggle.className = 'entities-tab__toggle';
  snapToggle.setAttribute('aria-label', 'Toggle entity grid snap');
  snapToggle.setAttribute('title', 'Toggle entity grid snap');

  placementRow.appendChild(placementLabel);
  placementRow.appendChild(snapToggle);
  placementSection.appendChild(placementTitle);
  placementSection.appendChild(placementRow);

  let assetPaletteController: AssetPaletteController | null = null;
  const assetPaletteContainer = document.createElement('div');
  if (assetRegistry) {
    assetPaletteController = createAssetPalette({
      container: assetPaletteContainer,
      assetRegistry,
      groupType: 'entities',
      title: 'Entity Asset Groups',
    });
  }

  const selectionSection = document.createElement('section');
  selectionSection.className = 'entities-tab__section';

  const selectionTitle = document.createElement('div');
  selectionTitle.className = 'entities-tab__selection-title';

  const selectionSubtitle = document.createElement('div');
  selectionSubtitle.className = 'entities-tab__selection-subtitle';

  selectionSection.appendChild(selectionTitle);
  selectionSection.appendChild(selectionSubtitle);

  const propertiesSection = document.createElement('section');
  propertiesSection.className = 'entities-tab__section';

  const propertiesTitle = document.createElement('div');
  propertiesTitle.className = 'entities-tab__section-title';
  propertiesTitle.textContent = 'Properties';

  const propertiesBody = document.createElement('div');
  propertiesBody.className = 'entities-tab__property-list';

  propertiesSection.appendChild(propertiesTitle);
  propertiesSection.appendChild(propertiesBody);

  root.appendChild(paletteSection);
  if (assetRegistry) {
    root.appendChild(assetPaletteContainer);
  }
  root.appendChild(placementSection);
  root.appendChild(selectionSection);
  root.appendChild(propertiesSection);
  container.appendChild(root);

  let selectedIds: string[] = [];
  let assetList: HTMLDataListElement | null = null;
  const assetListId = `entity-asset-options-${Math.random().toString(36).slice(2, 8)}`;

  function renderAssetOptions(project: Project | null): void {
    const options = collectAssetOptions(project);
    if (options.length === 0) {
      assetList?.remove();
      assetList = null;
      return;
    }

    if (!assetList) {
      assetList = document.createElement('datalist');
      assetList.id = assetListId;
      root.appendChild(assetList);
    }

    assetList.innerHTML = '';
    for (const option of options) {
      const opt = document.createElement('option');
      opt.value = option;
      assetList.appendChild(opt);
    }
  }

  function setSelectedEntityType(nextType: string | null): void {
    if (onEntityTypeSelect) {
      onEntityTypeSelect(nextType);
    } else {
      const editorState = getEditorState();
      if (editorState) {
        editorState.selectedEntityType = nextType;
      }
    }
    renderPalette();
  }

  function renderPalette(): void {
    const project = getProject();
    const editorState = getEditorState();
    const selectedType = editorState?.selectedEntityType ?? null;
    paletteList.innerHTML = '';

    if (!project || project.entityTypes.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'entities-tab__empty';
      empty.textContent = 'No entity types defined yet.';
      paletteList.appendChild(empty);
      return;
    }

    for (const entityType of project.entityTypes) {
      const row = document.createElement('div');
      row.className = 'entities-tab__palette-row';

      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'entities-tab__palette-button';
      button.textContent = entityType.displayName ?? entityType.name;
      button.classList.toggle('entities-tab__palette-button--active', entityType.name === selectedType);

      const tag = document.createElement('span');
      tag.className = 'entities-tab__palette-tag';
      tag.textContent = entityType.name;
      button.appendChild(tag);

      button.addEventListener('click', () => {
        setSelectedEntityType(entityType.name);
      });

      const placeButton = document.createElement('button');
      placeButton.type = 'button';
      placeButton.className = 'entities-tab__place-button';
      placeButton.textContent = 'Place';
      placeButton.addEventListener('click', () => {
        setSelectedEntityType(entityType.name);
        config.onEntityTypePlace?.(entityType.name);
      });

      row.appendChild(button);
      row.appendChild(placeButton);
      paletteList.appendChild(row);
    }
  }

  function renderEmptyProperties(message: string): void {
    propertiesBody.innerHTML = '';
    const empty = document.createElement('div');
    empty.className = 'entities-tab__empty';
    empty.textContent = message;
    propertiesBody.appendChild(empty);
  }

  function renderSelectionSummary(entities: EntityInstance[]): void {
    if (entities.length === 0) {
      selectionTitle.textContent = 'No entity selected';
      selectionSubtitle.textContent = 'Tap an entity to view details.';
      return;
    }

    if (entities.length > 1) {
      selectionTitle.textContent = `${entities.length} entities selected`;
      selectionSubtitle.textContent = 'Multi-select editing coming soon.';
      return;
    }

    const project = getProject();
    const entity = entities[0];
    const entityType = project?.entityTypes.find((type) => type.name === entity.type);
    selectionTitle.textContent = getEntityTypeLabel(entityType);
    selectionSubtitle.textContent = `ID: ${entity.id}`;
  }

  function applyPropertyChange(
    entity: EntityInstance,
    definition: PropertyDefinition,
    nextValue: string | number | boolean
  ): void {
    const previousValue = entity.properties?.[definition.name];
    if (previousValue === nextValue) return;

    const previousUpdates = [
      {
        id: entity.id,
        properties: {
          [definition.name]: previousValue,
        },
      },
    ];

    const nextUpdates = [
      {
        id: entity.id,
        properties: {
          [definition.name]: nextValue,
        },
      },
    ];

    entityManager.updateEntityProperties(nextUpdates);

    const operation: Operation = {
      id: generateOperationId(),
      type: 'entity_property_change',
      description: `Edit ${definition.label ?? definition.name}`,
      execute: () => {
        entityManager.updateEntityProperties(nextUpdates);
      },
      undo: () => {
        entityManager.updateEntityProperties(previousUpdates);
      },
    };

    history.push(operation);
  }

  function renderProperties(entities: EntityInstance[]): void {
    const project = getProject();
    if (entities.length === 0) {
      renderEmptyProperties('Select an entity to edit its properties.');
      return;
    }

    if (entities.length > 1) {
      renderEmptyProperties('Multi-select editing is not available yet.');
      return;
    }

    const entity = entities[0];
    const entityType = project?.entityTypes.find((type) => type.name === entity.type);
    if (!entityType) {
      renderEmptyProperties('Entity type not found.');
      return;
    }

    renderAssetOptions(project);
    propertiesBody.innerHTML = '';

    const typeRow = document.createElement('div');
    typeRow.className = 'entities-tab__property-row';

    const typeLabel = document.createElement('label');
    typeLabel.className = 'entities-tab__label';
    typeLabel.textContent = 'Entity Type';

    const typeSelect = document.createElement('select');
    typeSelect.className = 'entities-tab__input';

    const entityTypes = project?.entityTypes ?? [];
    for (const candidate of entityTypes) {
      const option = document.createElement('option');
      option.value = candidate.name;
      option.textContent = `${getEntityTypeLabel(candidate)} (${candidate.name})`;
      typeSelect.appendChild(option);
    }
    typeSelect.value = entity.type;

    const typeActionRow = document.createElement('div');
    typeActionRow.className = 'entities-tab__action-row';

    const applyTypeButton = document.createElement('button');
    applyTypeButton.type = 'button';
    applyTypeButton.className = 'entities-tab__action-button';
    applyTypeButton.textContent = 'Apply Type';

    typeActionRow.appendChild(applyTypeButton);
    typeRow.appendChild(typeLabel);
    typeRow.appendChild(typeSelect);
    typeRow.appendChild(typeActionRow);
    propertiesBody.appendChild(typeRow);

    const applyEntityTypeChange = (): void => {
      const nextType = typeSelect.value;
      if (!nextType || nextType === entity.type) return;

      const previousType = entity.type;
      entityManager.changeEntityType(entity.id, nextType);

      const operation: Operation = {
        id: generateOperationId(),
        type: 'entity_property_change',
        description: `Change entity type to ${nextType}`,
        execute: () => {
          entityManager.changeEntityType(entity.id, nextType);
        },
        undo: () => {
          entityManager.changeEntityType(entity.id, previousType);
        },
      };

      history.push(operation);
      renderSelection();
    };

    applyTypeButton.addEventListener('click', applyEntityTypeChange);

    const canApplyType = typeSelect.value !== entity.type;
    applyTypeButton.disabled = !canApplyType;

    typeSelect.addEventListener('change', () => {
      applyTypeButton.disabled = typeSelect.value === entity.type;
    });

    const animationRow = document.createElement('div');
    animationRow.className = 'entities-tab__property-row';

    const animationLabel = document.createElement('label');
    animationLabel.className = 'entities-tab__label';
    animationLabel.textContent = 'Animation';

    const animationSetSelect = document.createElement('select');
    animationSetSelect.className = 'entities-tab__input';
    const noSetOption = document.createElement('option');
    noSetOption.value = '';
    noSetOption.textContent = 'Animation Set: None';
    animationSetSelect.appendChild(noSetOption);

    const animationSelect = document.createElement('select');
    animationSelect.className = 'entities-tab__input';

    const noneOption = document.createElement('option');
    noneOption.value = '';
    noneOption.textContent = 'Animation Clip: None';
    animationSelect.appendChild(noneOption);

    const animations = assetRegistry?.getAnimations() ?? [];
    const animationSets = assetRegistry?.getAnimationSets() ?? [];
    const stateMachines = assetRegistry?.getAnimStateMachines() ?? [];

    for (const animationSet of animationSets) {
      const option = document.createElement('option');
      option.value = animationSet.id;
      option.textContent = `${animationSet.name} (${animationSet.id})`;
      animationSetSelect.appendChild(option);
    }

    for (const animation of animations) {
      const option = document.createElement('option');
      option.value = animation.id;
      option.textContent = `${animation.name} (${animation.id})`;
      animationSelect.appendChild(option);
    }

    const stateMachineSelect = document.createElement('select');
    stateMachineSelect.className = 'entities-tab__input';
    const noSmOption = document.createElement('option');
    noSmOption.value = '';
    noSmOption.textContent = 'State Machine: None';
    stateMachineSelect.appendChild(noSmOption);

    for (const sm of stateMachines) {
      const option = document.createElement('option');
      option.value = sm.id;
      option.textContent = `${sm.name} (${sm.id})`;
      stateMachineSelect.appendChild(option);
    }

    const currentAnimationSetId = String(entity.properties?.animationSetId ?? '');
    animationSetSelect.value = currentAnimationSetId;
    if (animationSetSelect.value !== currentAnimationSetId) {
      animationSetSelect.value = '';
    }

    const currentAnimationId = String(entity.properties?.animationId ?? '');
    animationSelect.value = currentAnimationId;
    if (animationSelect.value !== currentAnimationId) {
      animationSelect.value = '';
    }

    const currentStateMachineId = String(entity.properties?.animStateMachineId ?? '');
    stateMachineSelect.value = currentStateMachineId;
    if (stateMachineSelect.value !== currentStateMachineId) {
      stateMachineSelect.value = '';
    }

    const animationHint = document.createElement('div');
    animationHint.className = 'entities-tab__hint';
    animationHint.textContent = assetRegistry
      ? animationSets.length > 0 || animations.length > 0 || stateMachines.length > 0
        ? 'State machines override sets. Sets override single clips.'
        : 'No saved animations, sets, or state machines yet. Create them in the Animation tab.'
      : 'Animation assignment is unavailable without the asset registry.';

    const animationActionRow = document.createElement('div');
    animationActionRow.className = 'entities-tab__action-row';

    const editAnimationButton = document.createElement('button');
    editAnimationButton.type = 'button';
    editAnimationButton.className = 'entities-tab__action-button';
    editAnimationButton.textContent = 'Edit Animation';
    editAnimationButton.disabled = !currentAnimationId;

    editAnimationButton.addEventListener('click', () => {
      const animationId = String(entity.properties?.animationId ?? '');
      if (!animationId) return;
      config.onEditAnimation?.(animationId);
    });

    const applyAnimationChange = (
      nextAnimationId: string,
      nextAnimationSetId: string,
      nextStateMachineId: string
    ): void => {
      const previousAnimationIdRaw = entity.properties?.animationId;
      const previousAnimationSetIdRaw = entity.properties?.animationSetId;
      const previousStateMachineIdRaw = entity.properties?.animStateMachineId;
      const previousAnimationId =
        typeof previousAnimationIdRaw === 'string' ? previousAnimationIdRaw : undefined;
      const previousAnimationSetId =
        typeof previousAnimationSetIdRaw === 'string' ? previousAnimationSetIdRaw : undefined;
      const previousStateMachineId =
        typeof previousStateMachineIdRaw === 'string' ? previousStateMachineIdRaw : undefined;
      if (
        previousAnimationId === (nextAnimationId || undefined)
        && previousAnimationSetId === (nextAnimationSetId || undefined)
        && previousStateMachineId === (nextStateMachineId || undefined)
      ) {
        editAnimationButton.disabled = !nextAnimationId;
        return;
      }

      const previousStateRaw = entity.properties?.animationState;
      const previousAnimationState =
        typeof previousStateRaw === 'string' ? previousStateRaw : undefined;
      const nextAnimationState = (nextAnimationId || nextAnimationSetId || nextStateMachineId)
        ? previousAnimationState ?? 'idle'
        : undefined;

      const nextUpdates = {
        id: entity.id,
        properties: {
          animationId: nextAnimationId || undefined,
          animationSetId: nextAnimationSetId || undefined,
          animStateMachineId: nextStateMachineId || undefined,
          animationState: nextAnimationState,
        },
      };

      const previousUpdates = {
        id: entity.id,
        properties: {
          animationId: previousAnimationId,
          animationSetId: previousAnimationSetId,
          animStateMachineId: previousStateMachineId,
          animationState: previousAnimationState,
        },
      };

      entityManager.updateEntityProperties([nextUpdates]);

      const operation: Operation = {
        id: generateOperationId(),
        type: 'entity_property_change',
        description: nextStateMachineId
          ? 'Assign entity state machine'
          : nextAnimationSetId
            ? 'Assign entity animation set'
            : nextAnimationId
              ? 'Assign entity animation'
              : 'Clear entity animation',
        execute: () => {
          entityManager.updateEntityProperties([nextUpdates]);
        },
        undo: () => {
          entityManager.updateEntityProperties([previousUpdates]);
        },
      };

      history.push(operation);
      editAnimationButton.disabled = !nextAnimationId;
    };

    stateMachineSelect.disabled = !assetRegistry;
    stateMachineSelect.addEventListener('change', () => {
      applyAnimationChange(
        animationSelect.value,
        animationSetSelect.value,
        stateMachineSelect.value
      );
    });

    animationSetSelect.disabled = !assetRegistry;
    animationSetSelect.addEventListener('change', () => {
      applyAnimationChange(
        animationSelect.value,
        animationSetSelect.value,
        stateMachineSelect.value
      );
    });

    animationSelect.disabled = !assetRegistry;
    animationSelect.addEventListener('change', () => {
      applyAnimationChange(
        animationSelect.value,
        animationSetSelect.value,
        stateMachineSelect.value
      );
    });

    animationActionRow.appendChild(editAnimationButton);
    animationRow.appendChild(animationLabel);
    animationRow.appendChild(stateMachineSelect);
    animationRow.appendChild(animationSetSelect);
    animationRow.appendChild(animationSelect);
    animationRow.appendChild(animationHint);
    animationRow.appendChild(animationActionRow);
    propertiesBody.appendChild(animationRow);

    const definitions = entityType.properties ?? [];
    if (definitions.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'entities-tab__empty';
      empty.textContent = 'No editable type-specific properties for this entity.';
      propertiesBody.appendChild(empty);
      return;
    }

    for (const definition of definitions) {
      const row = document.createElement('div');
      row.className = 'entities-tab__property-row';

      const label = document.createElement('label');
      label.className = 'entities-tab__label';
      label.textContent = definition.label ?? definition.name;

      const hint = document.createElement('div');
      hint.className = 'entities-tab__hint';
      const hintText = buildConstraintHint(definition);
      if (hintText) {
        hint.textContent = hintText;
      } else {
        hint.textContent = '';
      }

      const error = document.createElement('div');
      error.className = 'entities-tab__error';
      error.textContent = '';

      const setError = (message: string | null): void => {
        if (message) {
          row.classList.add('entities-tab__property-row--error');
          error.textContent = message;
        } else {
          row.classList.remove('entities-tab__property-row--error');
          error.textContent = '';
        }
      };

      if (definition.type === 'boolean') {
        const toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = 'entities-tab__toggle';

        const updateToggle = (value: boolean): void => {
          toggle.textContent = value ? 'On' : 'Off';
          toggle.classList.toggle('entities-tab__toggle--active', value);
        };

        const currentValue = Boolean(entity.properties?.[definition.name] ?? definition.default);
        updateToggle(currentValue);

        toggle.addEventListener('click', () => {
          const nextValue = !entity.properties?.[definition.name];
          if (!validatePropertyValue(nextValue, definition)) {
            setError('Invalid value.');
            return;
          }
          setError(null);
          applyPropertyChange(entity, definition, nextValue);
          updateToggle(nextValue);
        });

        row.appendChild(label);
        row.appendChild(toggle);
      } else {
        const input = document.createElement('input');
        input.className = 'entities-tab__input';
        input.type = definition.type === 'number' ? 'number' : 'text';
        if (definition.type === 'number') {
          input.step = 'any';
        }

        const value = entity.properties?.[definition.name] ?? definition.default;
        input.value = value !== undefined ? String(value) : '';

        if (definition.type === 'assetRef' && assetList) {
          input.setAttribute('list', assetListId);
        }

        input.addEventListener('change', () => {
          const raw = input.value;
          let parsed: string | number | boolean = raw;

          if (definition.type === 'number') {
            parsed = Number(raw);
            if (raw.trim() === '' || Number.isNaN(parsed)) {
              setError('Enter a valid number.');
              return;
            }
          }

          if (!validatePropertyValue(parsed, definition)) {
            setError('Invalid value.');
            return;
          }

          setError(null);
          applyPropertyChange(entity, definition, parsed);
        });

        row.appendChild(label);
        row.appendChild(input);
      }

      if (hintText) {
        row.appendChild(hint);
      }
      row.appendChild(error);
      propertiesBody.appendChild(row);
    }
  }

  function renderSelection(): void {
    const entities = selectedIds.length > 0 ? entityManager.getEntities(selectedIds) : [];
    renderSelectionSummary(entities);
    renderProperties(entities);
  }

  function updateSnapToggle(nextValue?: boolean): void {
    const editorState = getEditorState();
    const isEnabled = nextValue ?? editorState?.entitySnapToGrid ?? true;
    snapToggle.textContent = isEnabled ? 'On' : 'Off';
    snapToggle.classList.toggle('entities-tab__toggle--active', isEnabled);
  }

  snapToggle.addEventListener('click', () => {
    const editorState = getEditorState();
    const nextValue = !(editorState?.entitySnapToGrid ?? true);
    if (config.onEntitySnapChange) {
      config.onEntitySnapChange(nextValue);
    } else if (editorState) {
      editorState.entitySnapToGrid = nextValue;
    }
    updateSnapToggle(nextValue);
  });

  function refresh(): void {
    renderPalette();
    renderSelection();
    updateSnapToggle();
  }

  refresh();

  return {
    setSelection(nextIds: string[]): void {
      selectedIds = [...nextIds];
      renderSelection();
    },
    refresh,
    destroy(): void {
      assetPaletteController?.destroy();
      root.remove();
      styleEl.remove();
      assetList?.remove();
    },
  };
}

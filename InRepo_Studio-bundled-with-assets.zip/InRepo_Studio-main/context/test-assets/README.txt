InRepo Studio - Minimal Test Assets (32x32)

Drop this zip's 'game/assets' folder into your repo at game/assets.

This set matches game/project.json tileCategories:
- terrain: grass.png, dirt.png, water.png, stone.png
- props: tree.png, rock.png, bush.png

Notes:
- dirt.png is a flowered-grass stand-in (still great for testing)
- stone.png is a wood/plank stand-in (just to have a very distinct terrain tile)
